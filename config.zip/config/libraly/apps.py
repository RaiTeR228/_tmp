from django.apps import AppConfig


class LibralyConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "libraly"
